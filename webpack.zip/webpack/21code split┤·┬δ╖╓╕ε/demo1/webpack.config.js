
const {resolve} = require('path')
const HtmlWebpackPlugin = require('html-webpack-plugin');
// 定义nodejs环境变量，决定使用browserslist的哪个环境
process.env.NOOD_ENV = "production"

module.exports = {
  entry: {
    // 多入口：有一个入口，最终就会有一个bundle
    index: "./src/js/index.js",
    test: "./src/js/test.js"
  },
  output: {
    // [name] 取文件名
    filename: 'js/[name].[contenthash:10].js',
    path: resolve(__dirname,'build')
  },
  plugins: [
    new HtmlWebpackPlugin({
      template: './src/index.html',
      minify: {
        collapseWhitespace: true,
        removeComments: true
      }
    })
  ],
  mode: "production",
}