import $ from 'jquery'
export function mull(x,y) {
  return x * y
}
export function count(x,y) {
  return x - y
}
console.log(mull(11,11));
console.log($);