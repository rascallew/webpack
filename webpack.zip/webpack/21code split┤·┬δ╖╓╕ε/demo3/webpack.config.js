
const {resolve} = require('path')
const HtmlWebpackPlugin = require('html-webpack-plugin');
// 定义nodejs环境变量，决定使用browserslist的哪个环境
process.env.NOOD_ENV = "production"

module.exports = {
  // 单入口
  entry: "./src/js/index.js",
  output: {
    // [name] 取文件名
    filename: 'js/[name].[contenthash:10].js',
    path: resolve(__dirname,'build')
  },
  plugins: [
    new HtmlWebpackPlugin({
      template: './src/index.html',
      minify: {
        collapseWhitespace: true,
        removeComments: true
      }
    })
  ],
  /**
   * 1、可以将node_modules中单独打包成一个chunk最终输出
   * 2、自动分析多入口chunk中，有没有公共的文件，如果有就会被打包成一个单独的chunk
   */
  optimization: {
    splitChunks: {
      chunks: 'all'
    }
  },
  mode: "production",

}