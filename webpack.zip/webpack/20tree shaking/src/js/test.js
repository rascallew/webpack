
export function mull(x,y) {
  return x * y
}
export function count(x,y) {
  return x - y
}