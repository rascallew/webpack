
console.log("printjs 被答应了");
export default print = function() {
  console.log("hello world11111111111111111");
}
