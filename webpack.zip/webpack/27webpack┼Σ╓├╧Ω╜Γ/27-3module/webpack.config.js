
const HtmlWebpackPlugin = require('html-webpack-plugin')
const {resolve} = require('path')
module.exports = {
  entry: './src/index.js',
  output: {
    filename: 'js/[name].js',
    path: resolve(__dirname,'build'),
  },
  module: {
    rules: [
      // loader配置
      {
        test:/\.css$/,
        // 多个loader
        use:['style-loader','css-loader']
      },
      {
        test:/\.js$/,
        // 单个loader
        // 排除node_modules下的js文件
        exclude: /node_modules/,
        // 只检查src下的js文件
        include: resolve(__dirname,'src'),
        // 优先执行
        // enforce: 'pre',
        // 延后执行
        enforce: 'post',
        loader: 'eslint-loader'
      },
      {
        // 以下loader只会生效一个
        oneOf: [

        ]
      }
    ]
  },
  plugins:[
    new HtmlWebpackPlugin()
  ],
  mode: 'development'
}