

// import add from './add'
import count from './count'
console.log("=---------------");
// console.log(add(2,2));
console.log(count(3,1));