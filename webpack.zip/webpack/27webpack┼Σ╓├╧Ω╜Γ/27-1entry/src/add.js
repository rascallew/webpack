

function add(x,y) {
  return x + y
}
export default add