
const HtmlWebpackPlugin = require('html-webpack-plugin')
const {resolve} = require('path')
module.exports = {
  entry: './src/js/index.js',
  output: {
    filename: 'js/[name].js',
    path: resolve(__dirname,'build'),
  },
  module: {
    rules: [
      // loader配置
      {
        test:/\.css$/,
        // 多个loader
        use:['style-loader','css-loader']
      }
    ]
  },
  plugins:[
    new HtmlWebpackPlugin()
  ],
  mode: 'production',
  // 解析模块的规则
  resolve: {
    // 配置解析模块的别名 ,优点：简写路径
    alias: {
      $css: resolve(__dirname,'src/css'),
    },
    // 配置省略文件路径后缀名
    extensions: ['.js','json','.css','.jsx'],
    // 告诉webpack 解析模块的是去哪个目录
    modules:[resolve(__dirname,"../../node_modules"),'node_modules']
  },
  optimization: {
    splitChunks: {
      chunks: 'all',
      // 默认值可以不写
        /**
          *  minSize: 30 * 1024, // 分割的chunk最小为30kb
          maxSize: 0, // 最大没有限制
          minChunks: 1, // 要提取的chunk最少哟被引用1次
          maxAsyncRequests: 5, // 按需加载时并行加载的文件最大数量
          maxInttialRequests: 3, // 入口js文件的最大并行请求数量
          automaticNameDelimiter: '~', // 名称连接符
          name: true, // 可以使用命名规则
          cacheGroups: { // 分割chunk的组
            // node_modules文件会被打包到venders 组的chunk中 --> venders-xxx.js
            venders: {
              test:/[\\/]node_modules[\\/]/,
              //优先级
              priority: -10
            },
            default: {
              // 要提取chunk最少被引用2次
              miniChunks: 2,
              //优先级
              priority: -20,
              // 如果当前要打包的模块，和之前已经被提取的模块时是同一个，就会复用，而不是重新打包模块
              reuseExistingChunk:true,
            }
          }
          */
    }
  }
}