
const HtmlWebpackPlugin = require('html-webpack-plugin')
const {resolve} = require('path')
module.exports = {
  entry: './src/index.js',
  output: {
    filename: 'js/[name].js',
    path: resolve(__dirname,'build'),
    // 所有资源的引入公共路径的前缀 --> 'imgs/a.jpg' -->'/imgs/a.jpg'
    publicPath: '/',
    chunkFilename: '[name]_chunk.js', // 非入口chunk名称
    library: '[name]', // 整个库向外暴露的变量名
    // libraryTarget: 'window' //变量名添加到哪个上 browser
    // libraryTarget: 'global' //变量名添加到哪个上 node
    libraryTarget: 'commonjs'
  },
  plugins:[
    new HtmlWebpackPlugin()
  ],
  mode: 'development'
}