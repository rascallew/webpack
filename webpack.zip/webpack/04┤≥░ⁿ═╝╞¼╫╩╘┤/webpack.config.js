const {resolve} = require('path')
const HtmlWebpackPlugin = require('html-webpack-plugin')

module.exports = {
  entry: './src/index.js',
  output: {
    filename:'built.js',
    path: resolve(__dirname,'build')
  },
  module: {
    rules: [
      {
        test: /\.less$/,
        use:[
          "style-loader",
          "css-loader",
          "less-loader"
        ]
      },
      {
        test: /\.(JPG|png|webp)$/,
        use: [
         {
           loader:'url-loader',
          options: {
            // 图片大小小于8kb，就会被base64处理
            // 优点：减少请求数据（减轻服务器压力）
            // 缺点：图片体积会变大
            limit: 8 * 1024,
            // 因为url-loader默认使用的是es6模块解析，而html-loader引入的图片是commonjs
            // 解析时会出问题：[object Module]
            // 解决： 关闭url-loader中的es6模块化，使用commonjs解析
            esModule: false,
            name:'[hash:10].[ext]'
          }
         }
        ],
        // type:'javascript/auto'
      },
      {
        test:/\.html$/,
        loader: 'html-loader',
        options: {
          esModule: false
        }
      }
      /**
       * 打包其他资源
       * {
       * 排除某些资源
       * exclude:/\.(css|js|html)$/,
       * loader: 'file-loader'
       * }
       */
    ]
  },
  plugins: [
    new HtmlWebpackPlugin({
      template:'./src/index.html'
    })
  ],
  mode: 'development'
}