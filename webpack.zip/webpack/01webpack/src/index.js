// 入口文件
/**
 * 
 * @param {*} x 
 * @param {*} y 
 * @returns 
 * 1.运行指令
 *  开发环境：webpack ./src/index.js -o ./build/built.js --mode=development
 *  生产环境： webpack ./src/index.js -o ./build/built.js --mode=production
 * 
 * 2. 结论：
 * webpack能处理js/json,不能处理css/img等其他资源
 * 生产环境和生产环境都能将ES6模块化编译成浏览器能识别的模块化
 */
import data from './data.json'
import './index.css'
console.log(data);
function add(x,y) {
  return x + y
}

console.log(add(1,2));