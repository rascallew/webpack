/**
 * 开发环境配置： 能让代码运行
 */


const HtmlWebpackPlugin = require('html-webpack-plugin')
const {resolve} = require('path')
module.exports = {
  entry: './src/index.js',
  output: {
    filename:'built.js',
    path: resolve(__dirname,'build')
  },
  module: {
    //loader的配置
    rules:[
      {
        test:/\.less$/,
        use: ["style-loader","css-loader","less-loader"]
      },
      {
        //处理css资源
        test:/\.css$/,
        use: ["style-loader","css-loader"]
      },
      {
        //处理图片资源
        test: /\.(jpg|png|gif|jijf|webp)$/,
        loader: 'url-loader',
        options: {
          limit: 8 * 1024,
          name:'[hash:10].[ext]',
          esModule: false,
          // outputPath:'img'  打包到img目录下
        }
      },
      {
        // 处理html的图片资源
        test:/\.html$/,
        loader: 'html-loader',
        options: {
          // 关闭es6模块化
          esModule: false
        }
      },
      {
        // 其他资源
        exclude:/\.(html|js|css|less|jpg|png|webp|jijf|gif)/,
        loader: 'file-loader',
        options: {
          name:'[hash:10].[ext]'
        }
      }
    ]
  },
  plugins: [
    // plugin的配置
    new HtmlWebpackPlugin({
      template: './src/index.html'
    })
  ],
  mode: "development",
  devServer: {
    static: {
      directory: resolve(__dirname,'build')
    },
    compress: true,
    port: 3000,
    open: true
  }
}