 import '../css/index.css'
 
 import {mull} from './test.js'
 function sum(...args) {
   return args.reduce((p, c) => p + c, 0)
 }
 // eslint-disable-next-line
 console.log(sum(1, 2, 3, 4,5));
 // eslint-disable-next-line
 console.log(mull(5,5));

 /**
  * 1.eslint 不认识window、navigator全局变量
  * 解决：需要配置packge.json的全局变量
  *  "env": {
  *     "browser": true
  *   }
  * 2.sw代码必须运行在服务器上
  * 
  */
 // 注册serviceworker
 // 处理兼容性问题
 if('serviceWorker' in navigator) {
   window.addEventListener('click',() => {
     navigator.serviceWorker.register('/service-worker.js')
     .then(() => {
       console.log("serviceWorker注册成功了~");
     })
     .catch(() => {
      console.log("serviceWorker注册失败了~");
     })
   })
 }