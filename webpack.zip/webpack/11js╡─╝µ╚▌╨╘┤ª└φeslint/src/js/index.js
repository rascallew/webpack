// import "@babel/polyfill"
const add = (x,y) => x + y

console.log(add(11,11));

const res = new Promise((resolve,reject) =>{
  setTimeout(() => {
    console.log("定时器结束");
    resolve()
  }, 1000);
})
console.log(res);