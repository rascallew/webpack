
console.log("testjs被加载了-");
export function mull(x,y) {
  return x * y
}
export function count(x,y) {
  return x - y
}
