

const {resolve} = require('path')
const HtmlWebpackPlugin = require('html-webpack-plugin')

module.exports = {
  entry: './src/js/index.js',
  output: {
    filename:'js/built.js',
    path: resolve(__dirname,'build')
  },
  module: {
    rules: [

    ]
  },
  plugins: [
    new HtmlWebpackPlugin({
      template:'./src/index.html'
    })
  ],
  mode: 'production',
  externals: {
    // 忽略的包名 ---npm包名,拒绝jQuery这个包被打包进来
    jquery: 'jQuery'
  }
}