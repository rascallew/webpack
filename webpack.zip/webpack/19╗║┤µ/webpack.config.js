/**
 * 缓存：
 * babel 缓存
 *    cacheDirectory: true
 *      --> 让二次打包速度更快
 * 文件资源缓存
 *    hash:每次webpack构建打包生成的一个唯一哈希值
 *     问题：因为js和css同时使用的一个哈希值，如果重新打包，就会导致所有的缓存失效（可能我却只改动一个文件）
 *    chunkhash: 根据这个chunk生成的哈希值，如果打包来孕育同一个chunk，那么hash值旧一样
 *     问题：因为css是在js中被引入的，所以同属于一个chunk
 *    contenthash: 根据文件的内容生成哈希值，不同的文件哈希值一定不一样
 *    --> 让代码上线运行缓存更好的使用
 */
const {resolve} = require('path')
const MiniCssExtractPlugin = require('mini-css-extract-plugin')
const CssMinimizerPlugin = require("css-minimizer-webpack-plugin");
const HtmlWebpackPlugin = require('html-webpack-plugin');
// 定义nodejs环境变量，决定使用browserslist的哪个环境
process.env.NOOD_ENV = "production"

// 复用相同的loader
const commonCssLoader = [
  MiniCssExtractPlugin.loader,
  "css-loader",
  {
    // 还需要在packge.json 中定义browserslist
    loader: "postcss-loader",
    options: {
      ident: "postcss",
      plugins: () => [
        require('postcss-preset-env')()
      ]
    }
  }
]
module.exports = {
  entry: "./src/js/index.js",
  output: {
    filename: 'js/built.[contenthash:10].js',
    path: resolve(__dirname,'build')
  },
  module: {
    rules: [
         /**
         * 正常来讲 ，一个文件只能被一个loader处理
         * 当一个文件要被多个loader处理，那么一定要指定loader执行的先后顺序：
         * 先执行eslint，再执行babel
         */
      {
        // 在packege.json 中使用eslintConfig --> airbnb规则
        test: /\.js$/,
        exclude: /node_modules/,
        //  ***** 优先执行
        enforce: 'pre',
        loader: "eslint-loader",
        options: {
          fix: true
        }
      },
     {
       // 一下loader只会匹配一个（提升构架速度）
       // 注意： 不能有两个配置处理器同类型文件，所以把处理js的eslint-loader拿出来
       oneOf: [
        {
          test: /\.css$/,
          use: [...commonCssLoader]
        },
        {
          test: /\.css$/,
          use: [...commonCssLoader,"less-loader"]
        },
        {
          test: /\.js$/,
          exclude: /node_modules/,
          loader: "babel-loader",
          options: {
            presets: [
              [
                "@babel/preset-env",
                {
                  useBuiltIns: "usage",
                  corejs: {
                    version: 3
                  },
                  targets: {
                    chrome: "60",
                    firefox: '60',
                    ie: '9',
                    safari: "10",
                    edge: "17"
                  }
                }
              ]
            ],
            // 开启babel缓存
            // 第二次构建时，会读取之前的缓存
            cacheDirectory: true
          }
        },
        {
          test: /\.(png|jpg|gif)$/i, 
          loader: "url-loader",
          options: {
            limit: 8 * 1024,
            name: '[contenthash:10].[ext]',
            outputPath: 'imgs',
            esModule: false
          }
        },
        {
          test: /\.html$/,
          loader: "html-loader"
        },
        {
          exclude: /\.(js|css|less|html|png|gif|jpg|webp)$/i,
          loader: 'file-loader',
          options: {
            outputPath: 'media'
          }
        }
       ]
     }
    ]
  },
  plugins: [
    new HtmlWebpackPlugin({
      template: './src/index.html',
      minify: {
        collapseWhitespace: true,
        removeComments: true
      }
    }),
    new MiniCssExtractPlugin({
      filename: 'css/built.[contenthash:10].css'
    })
  ],
  mode: "production",
  devtool: 'source-map',
  // 压缩css
  optimization: {
    minimizer: [
      // 在 webpack@5 中，你可以使用 `...` 语法来扩展现有的 minimizer（即 `terser-webpack-plugin`），将下一行取消注释
      // `...`,
      new CssMinimizerPlugin(),
    ],
    minimize: true,
  }
}