/**
 * 使用dll技术，对某些库（第三方库：jQuery、vue、react....）进行打包
 * 当你运行 webpack时，默认查找 webpack.config.js配置文件
 * 需求： 需要运行 webpack.dll.js文件
 *  -->运行指令  webpack --config webpack.dll.js
 */
const {resolve} = require('path')
const webpack = require('webpack')
module.exports = {
  entry: {
    // 最终要打包生成的[name] --> jquery
    // ['jquery'] --> 要打包的库时jquery
    jquery: ['jquery']
  },
  output: {
    filename: '[name].js',
    path:resolve(__dirname,'dll'),
    library: '[name]_[hash]', // 从打包的库里面向外暴露出去的内容叫什么名字
  },
  plugins: [
    // 打包生成一个manifest.json --> 提供和jquery的映射
    new webpack.DllPlugin({
      name: '[name]_[hash]',//映射库的暴露的内容名称
      path: resolve(__dirname,'dll/manifest.json')// 输出文件的名称
    })
  ],
  mode: 'production'
}