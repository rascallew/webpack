import $  from 'jquery'

console.log($);