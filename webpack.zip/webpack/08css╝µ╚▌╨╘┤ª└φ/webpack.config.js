const HtmlWebpackPlugin = require("html-webpack-plugin");
const { resolve } = require("path");
const MiniCssExtractPlugin = require('mini-css-extract-plugin')

// 设置nodejs的环境变量
process.env.NOOD_ENV = "development"

module.exports = {
  entry: './src/js/index.js',
  output: {
    filename: 'js/built.js',
    path:resolve(__dirname,'build')
  },
  module: {
    rules: [
      {
        test: /\.css$/,
        use: [
          MiniCssExtractPlugin.loader,
          "css-loader",
          /**
           * css兼容性处理：postcss --> postcss-loader postcss-preset-env
           * 
           * 帮postcss 找到packge.json 中的browserslist里面的配置，通过配置加载指定的css兼容性
           *  "browserslist": {
           *        // 开发环境 --> 设置node环境变量:process.env.NOOD_ENV = "development"
                  "development": [
                    "last 1 chrome version",
                    "last 1 firefox version",
                    "last 1 safari version"
                  ],
                  // 生产环境 ： 默认是生产环境
                  "production": [
                    ">0.2%",
                    "not dead",
                    "not op_mini all"
                  ]
                }
           */
          //使用loader的默认配置
          // "post-loader",
          // 修改loader配置
          {
            loader: "postcss-loader",
            options: {
              ident: "postcss",
              plugins: () => [
                require('postcss-preset-env')()
              ]
            }
          }
        ]
      }
    ]
  },
  plugins: [
    new HtmlWebpackPlugin({
      template:'./src/index.html'
    }),
    new MiniCssExtractPlugin({
      filename:'css/built.css'
    })
  ],
  mode: "development"
}