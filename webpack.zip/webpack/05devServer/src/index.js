import './index.less'

function add(x,y) {
  return x * y
}
console.log(add(11,11));